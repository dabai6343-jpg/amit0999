const AmbientBackground = () => {
  return (
    <div className="fixed inset-0 z-[-1] overflow-hidden">
      {/* Soft gradient orbs for light aesthetic */}
      <div className="orb orb-primary w-[500px] h-[500px] absolute -top-[150px] -left-[150px] animate-float" />
      <div className="orb orb-secondary w-[400px] h-[400px] absolute bottom-[5%] -right-[100px] animate-float-delayed" />
      <div className="orb orb-primary w-[300px] h-[300px] absolute top-[40%] left-[60%] animate-float opacity-30" />
    </div>
  );
};

export default AmbientBackground;
