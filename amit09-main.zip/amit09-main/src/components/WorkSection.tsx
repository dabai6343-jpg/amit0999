import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
const WorkSection = () => {
  return <section id="work" className="py-32">
      <div className="container mx-auto px-8">
        <motion.div className="flex justify-between items-end mb-12" initial={{
        opacity: 0,
        y: 50
      }} whileInView={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8
      }} viewport={{
        once: true
      }}>
          <div>
            <h2 className="font-display text-4xl md:text-5xl mb-2 gradient-text">Works</h2>
            <p className="text-muted-foreground">2026 - Present</p>
          </div>
          <ArrowRight className="w-8 h-8 text-primary" />
        </motion.div>

        <motion.div className="grid grid-cols-12 gap-6" initial={{
        opacity: 0,
        y: 50
      }} whileInView={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8,
        delay: 0.2
      }} viewport={{
        once: true
      }}>
          <article className="card col-span-12 md:col-span-8 glass-strong rounded-2xl p-8 transition-all duration-500 hover:-translate-y-2 hover:shadow-xl">
            <div className="rounded-xl overflow-hidden mb-6">
              <iframe width="100%" height="350" src="https://www.youtube.com/embed/UWepdmxfnY0" title="Excel Project – Donut Chart" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen className="rounded-xl" />
            </div>
            <h3 className="font-display text-2xl mb-2 text-foreground">Excel Project – Donut Chart</h3>
            <p className="text-muted-foreground text-sm mb-4">
              Professional Excel project demonstrating donut chart creation.
            </p>
            <div className="flex gap-2 flex-wrap">
              {['Excel', 'Donut Chart', 'YouTube'].map(tag => <span key={tag} className="text-xs px-3 py-1 bg-primary/30 border border-primary/50 rounded-full text-foreground">
                  {tag}
                </span>)}
            </div>
          </article>
        </motion.div>
      </div>
    </section>;
};
export default WorkSection;