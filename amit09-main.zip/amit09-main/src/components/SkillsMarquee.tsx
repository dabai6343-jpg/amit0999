const skills = [
  'UI/UX DESIGN',
  '•',
  'FRONTEND DEV',
  '•',
  'MOTION',
  '•',
  '3D WEBGL',
  '•',
  'BRANDING',
  '•',
];

const SkillsMarquee = () => {
  return (
    <div className="w-full overflow-hidden py-16 glass -rotate-2 scale-110 my-16">
      <div className="flex gap-16 animate-scroll whitespace-nowrap">
        {[...skills, ...skills].map((skill, index) => (
          <span
            key={index}
            className="text-6xl font-display font-black text-stroke"
          >
            {skill}
          </span>
        ))}
      </div>
    </div>
  );
};

export default SkillsMarquee;
