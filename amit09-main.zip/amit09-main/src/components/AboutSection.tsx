import { motion } from 'framer-motion';
const stats = [{
  value: '0',
  label: 'Company Experience',
  color: 'text-secondary'
}, {
  value: '10',
  label: 'Academic Projects',
  color: 'text-primary'
}, {
  value: '100%',
  label: 'Learning Commitment',
  color: 'text-foreground'
}];
const AboutSection = () => {
  return <section id="about" className="py-32">
      <div className="container mx-auto px-8">
        <motion.div className="mb-12" initial={{
        opacity: 0,
        y: 50
      }} whileInView={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8
      }} viewport={{
        once: true
      }}>
          <h2 className="font-display text-4xl md:text-5xl gradient-text">​Personal Profile     </h2>
        </motion.div>

        <motion.div className="max-w-4xl mb-16" initial={{
        opacity: 0,
        y: 50
      }} whileInView={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8,
        delay: 0.2
      }} viewport={{
        once: true
      }}>
          <p className="text-xl md:text-2xl leading-relaxed text-foreground/90">
            Hello, I am Amit. I have completed a DCA (Diploma in Computer Applications) course and have strong knowledge of Microsoft Excel, PowerPoint, and Microsoft Word. Although I do not have company experience yet, I have successfully completed 10 academic projects that demonstrate my practical skills and dedication to learning. I am passionate about improving my computer skills, exploring modern tools, and growing professionally in today's digital world.
          </p>
        </motion.div>

        <motion.div className="flex flex-wrap gap-8" initial={{
        opacity: 0,
        y: 50
      }} whileInView={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8,
        delay: 0.4
      }} viewport={{
        once: true
      }}>
          {stats.map(({
          value,
          label,
          color
        }) => <div key={label} className="card flex-1 min-w-[200px] glass-strong rounded-2xl p-8 text-center transition-all duration-500 hover:-translate-y-2 hover:shadow-xl">
              <h3 className={`font-display text-5xl mb-2 ${color}`}>{value}</h3>
              <p className="text-muted-foreground">{label}</p>
            </div>)}
        </motion.div>
      </div>
    </section>;
};
export default AboutSection;