import CustomCursor from '@/components/CustomCursor';
import AmbientBackground from '@/components/AmbientBackground';
import FloatingDock from '@/components/FloatingDock';
import HeroSection from '@/components/HeroSection';
import SkillsMarquee from '@/components/SkillsMarquee';
import WorkSection from '@/components/WorkSection';
import AboutSection from '@/components/AboutSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';

const Index = () => {
  return (
    <>
      <CustomCursor />
      <AmbientBackground />
      <main>
        <HeroSection />
        <SkillsMarquee />
        <WorkSection />
        <AboutSection />
        <ContactSection />
        <Footer />
      </main>
      <FloatingDock />
    </>
  );
};

export default Index;
